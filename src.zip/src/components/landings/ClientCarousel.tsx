'use client';
import React, { useEffect, useState } from "react";

type Cliente = {
  id_cliente: number;
  description: string;
  url: string;
  logo: string;
};

type ClientCarouselProps = {
  scope: string;
  claim: string;
};

const ClientCarousel: React.FC<ClientCarouselProps> = ({ scope, claim }) => {
  const [clientes, setClientes] = useState<Cliente[]>([]);

  useEffect(() => {
    fetch(`http://localhost:3010/v1/store/clientes?maxItems=100&scope=${scope}`)
      .then((res) => res.json())
      .then(setClientes)
      .catch(console.error);
  }, [scope]);

  // duplicamos para efecto de loop infinito
  const logos = [...clientes, ...clientes];

  return (
    <section className="w-full max-w-7xl mx-auto px-6 py-12 text-center border-t border-gray-200 overflow-hidden">
      <h3 className="text-gray-500 mb-6 font-semibold text-lg">{claim}</h3>

      <div className="relative w-full overflow-hidden">
        <div className="flex animate-slide whitespace-nowrap gap-12">
          {logos.map((cliente, idx) => (
            <a
              key={`${cliente.id_cliente}-${idx}`}
              href={cliente.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-shrink-0 flex justify-center items-center"
            >
              <img
                src={`/logos/${cliente.logo}`}
                alt={cliente.description}
                title={cliente.description}
                className="h-14 object-contain hover:grayscale-0 transition duration-300"
              />
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ClientCarousel;
